#EXERCISE 7

UPDATE tb_movie a
JOIN tb_genre b
ON a.movie_genre_id=b.genre_id
SET movie_genre_id = '3' WHERE (`movie_id` = '9');

SELECT movie_title, genre_name FROM tb_movie as a
INNER JOIN tb_genre as b
on a.movie_genre_id=b.genre_id
WHERE movie_title='Ocho Apellidos Catalanes';
