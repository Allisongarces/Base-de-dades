-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: movies
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_movie_person`
--

DROP TABLE IF EXISTS `tb_movie_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_movie_person` (
  `movie_id` int NOT NULL,
  `person_id` int NOT NULL,
  `role_id` int NOT NULL,
  `movie_award_ind` char(1) NOT NULL,
  `created_by_user` varchar(10) NOT NULL DEFAULT 'OS_SGAD',
  `created_date` date DEFAULT NULL,
  `updated_date` date DEFAULT NULL,
  PRIMARY KEY (`movie_id`,`person_id`,`role_id`),
  KEY `fk_movper_person` (`person_id`),
  KEY `fk_movper_role` (`role_id`),
  CONSTRAINT `fk_movper_movie` FOREIGN KEY (`movie_id`) REFERENCES `tb_movie` (`movie_id`),
  CONSTRAINT `fk_movper_person` FOREIGN KEY (`person_id`) REFERENCES `tb_person` (`person_id`),
  CONSTRAINT `fk_movper_role` FOREIGN KEY (`role_id`) REFERENCES `tb_role` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_movie_person`
--

LOCK TABLES `tb_movie_person` WRITE;
/*!40000 ALTER TABLE `tb_movie_person` DISABLE KEYS */;
INSERT INTO `tb_movie_person` VALUES (1,1,2,'Y','OS_SGAD',NULL,NULL),(1,1,3,'N','OS_SGAD',NULL,NULL),(1,1,5,'N','OS_SGAD',NULL,NULL),(1,2,5,'N','OS_SGAD',NULL,NULL),(1,3,1,'N','OS_SGAD',NULL,NULL),(1,4,1,'N','OS_SGAD',NULL,NULL),(1,5,1,'Y','OS_SGAD',NULL,NULL),(1,6,1,'N','OS_SGAD',NULL,NULL),(1,41,1,'N','OS_SGAD',NULL,NULL),(2,6,1,'N','OS_SGAD',NULL,NULL),(2,7,2,'Y','OS_SGAD',NULL,NULL),(2,8,3,'N','OS_SGAD',NULL,NULL),(3,6,1,'N','OS_SGAD',NULL,NULL),(3,7,1,'N','OS_SGAD',NULL,NULL),(3,7,4,'N','OS_SGAD',NULL,NULL),(3,9,2,'N','OS_SGAD',NULL,NULL),(3,10,5,'N','OS_SGAD',NULL,NULL),(4,9,2,'N','OS_SGAD',NULL,NULL),(4,9,3,'N','OS_SGAD',NULL,NULL),(4,11,1,'N','OS_SGAD',NULL,NULL),(4,12,1,'N','OS_SGAD',NULL,NULL),(5,9,2,'N','OS_SGAD',NULL,NULL),(6,9,2,'N','OS_SGAD',NULL,NULL),(7,13,1,'N','OS_SGAD',NULL,NULL),(7,13,2,'N','OS_SGAD',NULL,NULL),(7,13,3,'N','OS_SGAD',NULL,NULL),(7,14,2,'N','OS_SGAD',NULL,NULL),(7,15,2,'N','OS_SGAD',NULL,NULL),(8,16,2,'N','OS_SGAD',NULL,NULL),(8,17,1,'N','OS_SGAD',NULL,NULL),(8,18,1,'N','OS_SGAD',NULL,NULL),(8,19,1,'N','OS_SGAD',NULL,NULL),(8,20,1,'N','OS_SGAD',NULL,NULL),(9,16,2,'N','OS_SGAD',NULL,NULL),(9,17,1,'N','OS_SGAD',NULL,NULL),(9,18,1,'N','OS_SGAD',NULL,NULL),(9,19,1,'N','OS_SGAD',NULL,NULL),(9,20,1,'N','OS_SGAD',NULL,NULL),(10,16,2,'N','OS_SGAD',NULL,NULL),(11,21,2,'N','OS_SGAD',NULL,NULL),(11,21,4,'N','OS_SGAD',NULL,NULL),(11,22,1,'N','OS_SGAD',NULL,NULL),(11,23,1,'N','OS_SGAD',NULL,NULL),(11,24,1,'N','OS_SGAD',NULL,NULL),(11,25,1,'N','OS_SGAD',NULL,NULL),(11,26,1,'N','OS_SGAD',NULL,NULL),(13,28,1,'Y','OS_SGAD',NULL,NULL),(13,28,2,'N','OS_SGAD',NULL,NULL),(14,29,1,'N','OS_SGAD',NULL,NULL),(14,30,1,'N','OS_SGAD',NULL,NULL);
/*!40000 ALTER TABLE `tb_movie_person` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-10  0:11:25
