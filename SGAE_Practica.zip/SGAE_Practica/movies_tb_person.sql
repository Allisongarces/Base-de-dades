-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: movies
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_person`
--

DROP TABLE IF EXISTS `tb_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_person` (
  `person_id` int NOT NULL,
  `person_name` varchar(100) NOT NULL,
  `person_country` varchar(40) DEFAULT NULL,
  `person_dob` date NOT NULL,
  `person_dod` date DEFAULT NULL,
  `person_parent_id` int DEFAULT NULL,
  `created_by_user` varchar(10) NOT NULL DEFAULT 'OS_SGAD',
  `created_date` date DEFAULT NULL,
  `updated_date` date DEFAULT NULL,
  PRIMARY KEY (`person_id`),
  KEY `fk_person_parent` (`person_parent_id`),
  CONSTRAINT `fk_person_parent` FOREIGN KEY (`person_parent_id`) REFERENCES `tb_person` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_person`
--

LOCK TABLES `tb_person` WRITE;
/*!40000 ALTER TABLE `tb_person` DISABLE KEYS */;
INSERT INTO `tb_person` VALUES (1,'Francis Ford Coppola','United States','1939-04-07',NULL,NULL,'OS_SGAD',NULL,NULL),(2,'Carmine Coppola','United States','1945-07-08',NULL,NULL,'OS_SGAD',NULL,NULL),(3,'Marlon Brando','United States','1924-04-03','2004-07-01',NULL,'OS_SGAD',NULL,NULL),(4,'Robert Duvall','United States','1931-01-05',NULL,NULL,'OS_SGAD',NULL,NULL),(5,'Martin Sheen','United States','1940-08-03',NULL,NULL,'OS_SGAD',NULL,NULL),(6,'Harrison Ford','United States','1942-07-13',NULL,NULL,'OS_SGAD',NULL,NULL),(7,'George Lucas','United States','1944-05-14',NULL,NULL,'OS_SGAD',NULL,NULL),(8,'Gary Kurtz','United States','1940-07-27',NULL,NULL,'OS_SGAD',NULL,NULL),(9,'Steven Spielberg','United States','1946-12-18',NULL,NULL,'OS_SGAD',NULL,NULL),(10,'John Williams','United States','1928-08-08',NULL,NULL,'OS_SGAD',NULL,NULL),(11,'Tom Hanks','United States','1956-07-09',NULL,NULL,'OS_SGAD',NULL,NULL),(12,'Catherine Zeta-Jones','Wales','1969-09-25',NULL,NULL,'OS_SGAD',NULL,NULL),(13,'Alfred Joseph Hitchcock','United Kingdom','1899-08-13','1980-04-29',NULL,'OS_SGAD',NULL,NULL),(14,'Anthony Perkins','United States','1934-04-04','1992-09-08',NULL,'OS_SGAD',NULL,NULL),(15,'Vera Miles','United States','1929-08-23',NULL,NULL,'OS_SGAD',NULL,NULL),(16,'Emilio Martinez Lazaro','Spain','1956-09-09',NULL,NULL,'OS_SGAD',NULL,NULL),(17,'Dani Rovira','Spain','1984-07-01',NULL,NULL,'OS_SGAD',NULL,NULL),(18,'Clara Lago','Spain','1986-04-17',NULL,NULL,'OS_SGAD',NULL,NULL),(19,'Carmen Machi','Spain','1964-08-09',NULL,NULL,'OS_SGAD',NULL,NULL),(20,'Karra Elejalde','Spain','1960-03-06',NULL,NULL,'OS_SGAD',NULL,NULL),(21,'Daniel Sanchez Arevalo','Spain','1970-06-08',NULL,NULL,'OS_SGAD',NULL,NULL),(22,'Quim Gutierrez','Spain','1981-03-27',NULL,NULL,'OS_SGAD',NULL,NULL),(23,'Robert Alamo','Spain','1970-05-06',NULL,NULL,'OS_SGAD',NULL,NULL),(24,'Hector Colome','Spain','1944-10-25','2015-02-28',NULL,'OS_SGAD',NULL,NULL),(25,'Veronica Echegui','Spain','1983-03-14',NULL,NULL,'OS_SGAD',NULL,NULL),(26,'Patrick Criado','Spain','1995-09-23',NULL,NULL,'OS_SGAD',NULL,NULL),(27,'Sean Connery','Scotland','1930-07-08',NULL,NULL,'OS_SGAD',NULL,NULL),(28,'Mel Gibson','Australia','1950-08-09',NULL,NULL,'OS_SGAD',NULL,NULL),(29,'Morgan Freeman','United States','1935-10-01',NULL,NULL,'OS_SGAD',NULL,NULL),(30,'Tim Robbins','United States','1949-06-07',NULL,NULL,'OS_SGAD',NULL,NULL),(41,'Charlie Sheen','United States','1965-09-03',NULL,5,'OS_SGAD',NULL,NULL),(42,'Emilio Estevez','United States','1962-05-12',NULL,5,'OS_SGAD',NULL,NULL),(43,'Ramón Estevez','United States','1963-08-07',NULL,5,'OS_SGAD',NULL,NULL),(44,'Reneé Estevez','United States','1967-04-02',NULL,5,'OS_SGAD',NULL,NULL),(45,'Paula Speert Sheen','United States','1986-01-06',NULL,41,'OS_SGAD',NULL,NULL),(46,'Bob Sheen','United States','2009-05-01',NULL,41,'OS_SGAD',NULL,NULL),(47,'Max Sheen','United States','2009-05-01',NULL,41,'OS_SGAD',NULL,NULL),(48,'Sam Sheen','United States','2004-03-09',NULL,41,'OS_SGAD',NULL,NULL),(49,'Lola Sheen','United States','2005-06-01',NULL,41,'OS_SGAD',NULL,NULL),(50,'Paula Jones-Sheen','United States','2003-07-06',NULL,45,'OS_SGAD',NULL,NULL),(51,'Paloma Rae Estevez','United States','1986-02-15',NULL,42,'OS_SGAD',NULL,NULL),(52,'Taylor Levi Estevez','United States','1984-06-22',NULL,42,'OS_SGAD',NULL,NULL);
/*!40000 ALTER TABLE `tb_person` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-10  0:11:25
